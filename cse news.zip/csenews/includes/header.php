 <!--Navbar-->
<nav class="navbar fixed-top navbar-expand-lg navbar-light white" style="background-color: #fcba03;">

  <div class="container-fluid"> 

    <a class="navbar-brand" href="index.php">
      <img src="images/logo.png" height="50" width="80" alt="mdb logo">
    </a>

    <!-- Collapse button -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
            aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Links -->
    <div class="collapse navbar-collapse" id="basicExampleNav">

      <!-- Left -->
      <ul class="navbar-nav mr-auto">
       

      <?php $query=mysqli_query($con,"select id,CategoryName from tblcategory");
while($row=mysqli_fetch_array($query))
{
?>

                    <li class="nav-item">
                      <a class="nav-link waves-effect" href="category.php?catid=<?php echo htmlentities($row['id'])?>"><?php echo htmlentities($row['CategoryName']);?></a>
                    </li>
<?php } ?>

      </ul>

      <!-- Right -->
      <ul class="navbar-nav nav-flex-icons">
        <li class="nav-item">
          <a href="https://www.facebook.com/jonu.yadav.399" class="nav-link waves-effect" target="_blank">
            <i class="fab fa-facebook-f"></i>
          </a>
        </li> 
        <li class="nav-item">
          <a href="https://twitter.com/i_kunalsingh" class="nav-link waves-effect" target="_blank">
            <i class="fab fa-twitter"></i>
          </a>
        </li>
        <li class="nav-item">
          <a href="https://github.com/acekaus" class="nav-link waves-effect"
             target="_blank">
            <i class="fab fa-github"></i>
          </a>
        </li>
        <li class="nav-item">
          <a role="button" href="#" data-toggle="modal"  data-target="#myModal" role="button"
             class="nav-link border border-dark rounded waves-effect mr-2" >
            <i class="far fa-newspaper"></i> Newsletter
          </a>
        </li>
      </ul>

    </div>

  </div>

</nav>
<!--/.Navbar-->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-smll" role="document">
        <div class="modal-content">
            <div class="modal-header bg-warning text-center">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                <h5 class="modal-title" id="myModalLabel">Subscribe to our Newsletter.</h5>
                <p>Get Daily Updates</p>
            </div>
            <div class="modal-body">
                <div class="row">
                    <form action="#">
                        <div class="form-group col-md-12">
                        <div class="input-group">
                            <span class="input-group-addon"></span>
                            <input type="email" class="form-control input-lg"  placeholder="Your email here">
                        </div>
                    </div>
                     <div class="form-group col-md-12">
                        <input type="submit" class="btn btn-warning btn-lg btn-block" value="Subscribe">
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

