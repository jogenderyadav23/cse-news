  <!-- Footer -->
<footer class="page-footer font-small blue pt-4" style="background-color: #fcba03;">

  <!-- Footer Links -->
  <div class="container-fluid text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-6 mt-md-0 mt-3">

        <!-- Content -->
        <h5 class="text-uppercase"><span style="color: blue">Cse</span> <span style="color: red">News</span></h5>
        <p>We’re impartial and independent, and every day we create distinctive, world-class programmes and content which inform, educate and entertain millions of people in the India and around the world.</p>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none pb-3">

      <!-- Grid column -->
      <div class="col-md-3 mb-md-0 mb-3">

        <!-- Links -->
        <h5 class="text-uppercase"></h5>

        <ul class="list-unstyled">
          <li>
            <a href="#!">About the Cse news</a>
          </li>
          <li>
            <a href="#!">Privacy Policy</a>
          </li>
          
          <li>
            <a href="#!">Parental Guidance</a>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-3 mb-md-0 mb-3">

        <!-- Links -->
        <h5 class="text-uppercase"></h5>

        <ul class="list-unstyled">
          <li>
            <a href="#!">Accessibility Help</a>
          </li>
          <li>
            <a href="#!">Cookies</a>
          </li>
          <li>
            <a href="#!">Contact us</a>
          </li>
          
        </ul>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">Developed by Kunal-11492,jogender-11486,ashwani-11474.
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->